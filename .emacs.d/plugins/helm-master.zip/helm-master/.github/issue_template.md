## Expected behavior


## Actual behavior from emacs-helm.sh if possible


## Steps to reproduce (recipe)


## Backtraces if some (M-x toggle-debug-on-error)


## Describe versions of helm, emacs, operating system etc.
