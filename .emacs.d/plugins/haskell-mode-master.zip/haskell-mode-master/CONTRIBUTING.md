Welcome nice stranger!

Haskell Mode loves contributors and we strive to go extra length to
help out both newcomers and serial contributors.

Haskell Mode project is managed according to rules outlined in the wiki:

https://github.com/haskell/haskell-mode/wiki/Contributing

> When I started contributing to haskell-mode I had 0 experience in Elisp, but it was super easy to learn it.
> -- [geraldus, 2016-01-16](https://github.com/haskell/haskell-mode/issues/1086#issuecomment-172177949)
